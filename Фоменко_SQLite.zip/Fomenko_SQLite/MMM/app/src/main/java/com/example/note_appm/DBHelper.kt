package com.example.note_appm

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteDatabase.CursorFactory

class DBHelper(context: Context, factory: CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        val queryCreateTable = ("CREATE TABLE $TABLE_NAME ("
                + "$ID_COLUMN INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$TITLENOTE_COLUMN TEXT, "
                + "$TEXTNOTE_COLUMN TEXT, "
                + "$CREATEDATE_COLUMN TEXT)")
        db.execSQL(queryCreateTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addNote(title: String, text: String, date: String) {
        val values = ContentValues()
        values.put(TITLENOTE_COLUMN, title)
        values.put(TEXTNOTE_COLUMN, text)
        values.put(CREATEDATE_COLUMN, date)

        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getAllNotes(): Cursor {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
    }

    fun updateNote(id: Long, title: String, text: String, date: String) {
        val values = ContentValues()
        values.put(TITLENOTE_COLUMN, title)
        values.put(TEXTNOTE_COLUMN, text)
        values.put(CREATEDATE_COLUMN, date)

        val db = this.writableDatabase
        db.update(TABLE_NAME, values, "$ID_COLUMN=?", arrayOf(id.toString()))
        db.close()
    }

    companion object {
        private const val DATABASE_NAME = "DBNotes.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_NAME = "Notes"
        const val ID_COLUMN = "id"
        const val TITLENOTE_COLUMN = "title"
        const val TEXTNOTE_COLUMN = "text"
        const val CREATEDATE_COLUMN = "date"
    }
}
