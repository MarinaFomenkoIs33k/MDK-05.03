package com.example.note_appm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.note_appm.databinding.ActivityNotesBinding
import java.text.SimpleDateFormat
import java.util.*

class NotesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val titleNote = binding.editTextTitle
        val textNote = binding.editTextContent
        val createDate = binding.editTextDate

        val intent = intent
        if (intent.hasExtra("ID") && intent.hasExtra("TITLE") &&
            intent.hasExtra("TEXT") && intent.hasExtra("DATE")) {
            val title = intent.getStringExtra("TITLE")
            val text = intent.getStringExtra("TEXT")
            val date = intent.getStringExtra("DATE")

            titleNote.setText(title)
            textNote.setText(text)
            createDate.setText(date)
        }

        binding.saveButton.setOnClickListener {
            val db = DBHelper(this, null)

            val id = intent.getLongExtra("ID", -1)
            val title = titleNote.text.toString()
            val text = textNote.text.toString()
            val date = createDate.text.toString()

            if (text.isNotEmpty() && title.isNotEmpty()) {
                if (id != -1L) {
                    db.updateNote(id, title, text, date)
                } else {
                    db.addNote(title, text, date)
                }

                Toast.makeText(this, "Изменения сохранены", Toast.LENGTH_LONG).show()

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Заполните пустые поля", Toast.LENGTH_LONG).show()
            }
        }
    }
}