package com.example.note_appm

import android.annotation.SuppressLint
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import com.example.note_appm.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var cursor: Cursor? = null

    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listNotes = binding.listView
        val addButton = binding.addButton

        addButton.setOnClickListener {
            val intent = Intent(this, NotesActivity::class.java)
            startActivity(intent)

        }

        val db = DBHelper(this, null)
        cursor = db.getAllNotes()

        val dataList = ArrayList<String>()

        if (cursor != null && cursor!!.moveToFirst()) {
            do {
                val title = cursor!!.getString(cursor!!.getColumnIndex(DBHelper.TITLENOTE_COLUMN))
                val text = cursor!!.getString(cursor!!.getColumnIndex(DBHelper.TEXTNOTE_COLUMN))

                val noteData = "$title\n$text"
                dataList.add(noteData)
            } while (cursor!!.moveToNext())
        }


        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dataList)
        listNotes.adapter = adapter

        cursor?.close()
    }
}