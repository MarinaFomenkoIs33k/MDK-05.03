package com.example.yyy

import retrofit2.http.GET
import retrofit2.http.Path

interface ProductAPI {
    //Используем get запрос продукта по id
    @GET("products/{id}")
    //Функция позволяющая нам вывести продукт, id продукта вы прописываете в MainActivity
    suspend fun getProductById(@Path("id") id: Int): Product
}