package com.example.zad_ms

import retrofit2.http.*

interface DummyJsonApi {

    @GET("products")
    suspend fun getProducts(): ProductsResponse

    @GET("products/{id}")
    suspend fun getProduct(@Path("id") id: Int): Product

    @POST("products/add")
    suspend fun addProduct(@Body product: AddProductRequest): AddProductResponse

    @DELETE("products/{id}")
    suspend fun deleteProduct(@Path("id") id: Int): Product

}