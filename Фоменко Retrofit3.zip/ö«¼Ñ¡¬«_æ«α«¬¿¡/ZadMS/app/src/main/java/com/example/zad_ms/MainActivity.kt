package com.example.zad_ms

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.flow.collectLatest

class MainActivity : AppCompatActivity() {

    private val viewModel: ProductViewModel by viewModels()
    private lateinit var adapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupRecyclerView()
        setupClickListeners()
        setupObservers()
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter()
        val recyclerView = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerViewProducts)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupClickListeners() {
        // GET - Загрузить продукты
        findViewById<Button>(R.id.btnGetProducts).setOnClickListener {
            viewModel.loadProducts()
        }

        // POST - Добавить продукт
        findViewById<Button>(R.id.btnAddProduct).setOnClickListener {
            showAddProductDialog()
        }

        // DELETE - Удалить продукт
        findViewById<Button>(R.id.btnDeleteProduct).setOnClickListener {
            showDeleteProductDialog()
        }
    }

    private fun setupObservers() {
        // Наблюдаем за списком продуктов
        lifecycleScope.launchWhenStarted {
            viewModel.products.collectLatest { products ->
                adapter.updateProducts(products)
            }
        }

        // Наблюдаем за сообщениями
        lifecycleScope.launchWhenStarted {
            viewModel.message.collectLatest { message ->
                findViewById<TextView>(R.id.tvMessage).text = message ?: "Готово"
            }
        }
    }

    private fun showAddProductDialog() {
        // Простой диалог для добавления продукта
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Добавить продукт")
            .setMessage("Используется POST запрос")
            .setPositiveButton("Добавить тестовый продукт") { _, _ ->
                // Добавляем тестовый продукт
                viewModel.addProduct(
                    title = "Новый продукт ${System.currentTimeMillis()}",
                    description = "Описание нового продукта",
                    price = 99.99,
                    brand = "TestBrand",
                    category = "smartphones"
                )
            }
            .setNegativeButton("Отмена", null)
            .create()

        dialog.show()
    }

    private fun showDeleteProductDialog() {
        // Простой диалог для удаления продукта
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Удалить продукт")
            .setMessage("Используется DELETE запрос\nВведите ID продукта для удаления:")
            .setView(android.widget.EditText(this).apply {
                hint = "ID продукта"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            })
            .setPositiveButton("Удалить") { dialogInterface, _ ->
                val editText = (dialogInterface as android.app.AlertDialog).findViewById<android.widget.EditText>(android.R.id.edit)
                val id = editText?.text?.toString()?.toIntOrNull()
                if (id != null) {
                    viewModel.deleteProduct(id)
                } else {
                    findViewById<TextView>(R.id.tvMessage).text = "Ошибка: Введите корректный ID"
                }
            }
            .setNegativeButton("Отмена", null)
            .create()
        dialog.show()
    }
}