package com.example.zad_ms

class ProductRepository {
    private val api = RetrofitInstance.api

    suspend fun getProducts(): Result<ProductsResponse> {
        return try {
            val response = api.getProducts()
            Result.Success(response)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun addProduct(title: String, description: String, price: Double, brand: String, category: String): Result<AddProductResponse> {
        return try {
            val request = AddProductRequest(title, description, price, brand, category)
            val response = api.addProduct(request)
            Result.Success(response)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun deleteProduct(id: Int): Result<Product> {
        return try {
            val response = api.deleteProduct(id)
            Result.Success(response)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }
}