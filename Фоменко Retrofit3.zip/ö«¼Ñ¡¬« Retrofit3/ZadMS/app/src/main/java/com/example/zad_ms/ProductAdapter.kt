package com.example.zad_ms

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProductAdapter(
    private var products: List<Product> = emptyList()
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tvProductTitle)
        val tvPrice: TextView = itemView.findViewById(R.id.tvProductPrice)
        val tvBrand: TextView = itemView.findViewById(R.id.tvProductBrand)
        val tvId: TextView = itemView.findViewById(R.id.tvProductId)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]

        holder.tvTitle.text = product.title
        holder.tvPrice.text = "Цена: $${product.price}"
        holder.tvBrand.text = "Бренд: ${product.brand}"
        holder.tvId.text = "ID: ${product.id}"
    }

    override fun getItemCount(): Int = products.size

    fun updateProducts(newProducts: List<Product>) {
        products = newProducts
        notifyDataSetChanged()
    }
}