package com.example.zad_ms

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ProductViewModel : ViewModel() {

    private val repository = ProductRepository()

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    init {
        loadProducts()
    }

    fun loadProducts() {
        viewModelScope.launch {
            when (val result = repository.getProducts()) {
                is Result.Success -> {
                    _products.value = result.data.products.take(10) // Берем первые 10 для простоты
                    _message.value = "Продукты загружены (${result.data.products.size} шт)"
                }
                is Result.Failure -> {
                    _message.value = "Ошибка загрузки: ${result.exception.message}"
                }
            }
        }
    }

    fun addProduct(title: String, description: String, price: Double, brand: String, category: String) {
        viewModelScope.launch {
            when (val result = repository.addProduct(title, description, price, brand, category)) {
                is Result.Success -> {
                    _message.value = "Продукт добавлен! ID: ${result.data.id}"
                    loadProducts()
                }
                is Result.Failure -> {
                    _message.value = "Ошибка добавления: ${result.exception.message}"
                }
            }
        }
    }

    fun deleteProduct(id: Int) {
        viewModelScope.launch {
            when (val result = repository.deleteProduct(id)) {
                is Result.Success -> {
                    _message.value = "Продукт удален: ${result.data.title}"
                    loadProducts()
                }
                is Result.Failure -> {
                    _message.value = "Ошибка удаления: ${result.exception.message}"
                }
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}

sealed class Result<out T> {
    data class Success<out T>(val data: T) : Result<T>()
    data class Failure(val exception: Exception) : Result<Nothing>()
}