package com.example.fomenko

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        val recyclerView: RecyclerView = findViewById(R.id.contactsRecyclerView)

        // Устанавливаем LayoutManager
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Создаем адаптер
        val adapter = ContactAdapter()

        // Создаем тестовые данные
        val contacts = listOf(
            Contact(name = "Анна Петрова", phone = "+7 911 123-45-67", email = "anna@gmail.com", avatarColor = android.graphics.Color.RED),
            Contact(name = "Иван Сидоров", phone = "+7 912 234-56-78", email = "ivan@yandex.ru", avatarColor = android.graphics.Color.BLUE),
            Contact(name = "Мария Иванова", phone = "+7 913 345-67-89", email = "maria@gmail.com", avatarColor = android.graphics.Color.GREEN),
            Contact(name = "Алексей Козлов", phone = "+7 914 456-78-90", email = "alex@mail.ru", avatarColor = android.graphics.Color.MAGENTA),
            Contact(name = "Елена Смирнова", phone = "+7 915 567-89-01", email = "elena@yandex.ru", avatarColor = android.graphics.Color.CYAN)
        )

        // Обновляем адаптер и настраиваем RecyclerView
        adapter.updateContacts(contacts)
        recyclerView.adapter = adapter
        recyclerView.itemAnimator = DefaultItemAnimator()

        // Добавляем разделитель между элементами
        recyclerView.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )
    }
}