package com.example.zadsm

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var tvCity: TextView
    private lateinit var tvTemperature: TextView
    private lateinit var tvDescription: TextView
    private lateinit var btnRefresh: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvError: TextView

    private val repository = WeatherRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvCity = findViewById(R.id.tvCity)
        tvTemperature = findViewById(R.id.tvTemperature)
        tvDescription = findViewById(R.id.tvDescription)
        btnRefresh = findViewById(R.id.btnRefresh)
        progressBar = findViewById(R.id.progressBar)
        tvError = findViewById(R.id.tvError)

        loadWeather("Moscow")

        btnRefresh.setOnClickListener {
            loadWeather("Moscow")
        }
    }

    private fun loadWeather(city: String) {
        progressBar.visibility = View.VISIBLE
        tvError.visibility = View.GONE

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val weather = repository.getWeather(city)

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE

                    if (weather != null) {
                        showWeather(weather)
                    } else {
                        showError("Не удалось загрузить погоду")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    showError("Ошибка: ${e.message}")
                }
            }
        }
    }

    private fun showWeather(weather: WeatherResponse) {
        tvCity.text = weather.cityName
        tvTemperature.text = "${weather.main.temperature.toInt()}°C"

        if (weather.weather.isNotEmpty()) {
            val description = weather.weather[0].description
            tvDescription.text = description.replaceFirstChar { it.uppercase() }
        }
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }
}