package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.lifecycle.lifecycleScope
import com.squareup.picasso.Picasso
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var imageView: ImageView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        progressBar = findViewById(R.id.progressBar)
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.executeAsyncTask(
            onPreExecute = {
                progressBar.visibility = View.VISIBLE
            },
            doInBackground = {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .get()
                    .url("https://rickandmortyapi.com/api/character")
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.e("MyErrorTag", response.message)
                        return@executeAsyncTask response.message
                    }
                    val jsonObj = JSONObject(response.body?.string())
                    return@executeAsyncTask (jsonObj
                        .getJSONArray("results")[0]
                            as JSONObject).getString("image")
                }
            },
            onPostExecute = {
                Picasso.get().load(it).into(imageView)
                progressBar.visibility = View.GONE
            }
        )
    }
}