package com.example.project0

import android.os.Bundle
import android.view.View
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity : AppCompatActivity() {
    private lateinit var progressBar: ProgressBar
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar = findViewById(R.id.progressBar)
        listView = findViewById(R.id.listViewData)

        loadData()
    }

    private fun loadData() {
        lifecycleScope.launch {
            try {
                progressBar.visibility = View.VISIBLE

                val result = withContext(Dispatchers.IO) {
                    val client = OkHttpClient()
                    val request: Request = Request.Builder()
                        .get()
                        .url("https://rickandmortyapi.com/api/character")
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            return@use "code: ${response.code}: ${response.message}"
                        }
                        response.body?.string() ?: ""
                    }
                }

                try {
                    val moshi: Moshi = Moshi.Builder().build()
                    val jsonAdapter = moshi.adapter(Rootobj::class.java)
                    val rootObj: Rootobj? = jsonAdapter.fromJson(result)

                    if (rootObj != null) {
                        listView.adapter = CharacterAdapter(this@MainActivity, rootObj.characters)
                    } else {
                        Toast.makeText(this@MainActivity, "Failed to parse data", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                progressBar.visibility = View.GONE
            }
        }
    }
}