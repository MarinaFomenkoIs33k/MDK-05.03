package com.example.raas

class text(val photo : String, val new_tovar : Int, val name : String, val price : Int, val pieces : String, val date : String) {
    override fun toString() : String {
        return "$new_tovar, $name, $price, $pieces, $date"
    }
}